import React, { useState } from 'react';
import StatesComponent from './Components/StatesComponent';
import CityList from './Components/CitiesComponent';
import ResultComponent from './Components/ResultComponent';

function App() {
  const [selectedStateId, setSelectedStateId] = useState(null);

  return (
    <div>
      {/* <StatesComponent onStateSelect={(stateId) => setSelectedStateId(stateId)} /> */}
      <StatesComponent selectedStateId={selectedStateId} onStateSelect={(stateId) => setSelectedStateId(stateId)} />
      <CityList stateId={selectedStateId} />
      <ResultComponent />
    </div>
  );
}

export default App;



// import React from 'react';
// import { BrowserRouter, Router, Routes, Route } from 'react-router-dom';
// import List from './Components/List';
// import ResultComponent from './Components/ResultComponent';

// function App() {
//   return (
//     <BrowserRouter>
//       <Router>
//         <Routes>
//           <Route path="/" element={<List />} />
//           <Route path="/result" element={<ResultComponent />} />
//         </Routes>
//       </Router>
//     </BrowserRouter>

//     // <Router>
//     //   <Routes>
//     //     <Route path="/" element={<List />} /> 
//     //     <Route path="/result" element={<ResultComponent />} /> 
//     //   </Routes>
//     // </Router>
//   );
// }

// export default App;
