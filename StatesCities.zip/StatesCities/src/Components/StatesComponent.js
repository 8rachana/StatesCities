import React, { useState, useEffect } from 'react';

function StatesComponent({ selectedStateId, onStateSelect }) {
  const [list, setList] = useState([]);
  const [selectedState, setSelectedState] = useState('');


  useEffect(() => {
    fetch('https://api.minebrat.com/api/v1/states')
      .then((res) => res.json())
      .then((data) => {
        setList(data);
        setSelectedState(selectedStateId); // Set selected state after data is available
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, [selectedStateId, onStateSelect]);


  const handleStateChange = (event) => {
    const newStateId = event.target.value;
    setSelectedState(newStateId);
    onStateSelect(newStateId);
  };
  const handleSubmit = () => {
    alert(`You submitted ${selectedState}`);
  };




  return (
    <div>
      <h1>State Dropdown</h1>
      <label htmlFor="stateSelect">Select a state:</label>
      <select id="stateSelect" value={selectedState} onChange={handleStateChange}>
        <option value="">States</option>
        {list.map((state) => (
          <option key={state.stateId} value={state.stateName}>
            {state.stateName}
          </option>
        ))}
      </select>
      {selectedState && <p>You selected: {selectedState}</p>}
      <button onClick={handleSubmit}>Submit</button>
    </div>
  )
}

export default StatesComponent;
