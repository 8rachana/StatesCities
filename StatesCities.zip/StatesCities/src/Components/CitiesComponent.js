    import React, { useState, useEffect } from 'react';

    function CityList({ stateId }) {
        const [cities, setCities] = useState([]);
        const [selectedCity, setSelectedCity] = useState('');



        useEffect(() => {
            fetch(`http://api.minebrat.com/api/v1/states/cities/1`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json();
                })
                .then((data) => {
                    setCities(data);
                })
                .catch((error) => {
                    console.error('Error fetching data:', error);
                });
        }, [stateId]);



        const handleCityChange = (event) => {
            setSelectedCity(event.target.value);
        };



        return (
            <div>
                <h1>Cities in State</h1>
                <label htmlFor="citySelect">Select a city:</label>
                <select
                    id="citySelect"
                    value={selectedCity}
                    onChange={handleCityChange}
                >
                    <option value="">Cities</option>
                    {cities.map((city) => (
                        <option key={city.cityId} value={city.cityName}>
                            {city.cityName}
                        </option>
                    ))}
                </select>
            </div>
        );
    }

    export default CityList;
