import React, { useState } from 'react';
import StatesComponent from './StatesComponent';
import CityList from './CitiesComponent';
import { Link, Route } from 'react-router-dom';
import ResultComponent from './ResultComponent';

function List() {
    const [selectedState, setSelectedState] = useState('');
    const [selectedCity, setSelectedCity] = useState('');

    const handleStateSelect = (state) => {
        setSelectedState(state);
    };

    const handleCitySelect = (city) => {
        setSelectedCity(city);
    };

    return (
        <div>
            <h1>List Component</h1>
            <StatesComponent onStateSelect={handleStateSelect} />
            <CityList state={selectedState} onCitySelect={handleCitySelect} />
            <Link to="/result">
                <button>Submit</button>
            </Link>
            <Route path="/result" element={<ResultComponent selectedStateName={selectedState} selectedCityName={selectedCity} />} />
        </div>
    );
}

export default List;
