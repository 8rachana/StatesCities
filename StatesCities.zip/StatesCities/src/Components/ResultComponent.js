import React from 'react';

function ResultComponent({ selectedStateName, selectedCityName }) {
    return (
        <div>
            {/* <h1>You Have selected {selectedCityName}, {selectedStateName}</h1> */}
        </div>
    );
}

export default ResultComponent;
